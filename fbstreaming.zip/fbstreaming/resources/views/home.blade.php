@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                        @if(auth::user()->facebook_provider_id)
                            <div class="row mb-3">
                                <label for="password" class="col-md-4 col-form-label text-md-end"></label>
                                <div class="col-md-6">
                                    <a class="btn btn-primary" href="{{ url('upload/live-streaming/facebook-video') }}"> Upload video to facebook for live streaming</a>
                                </div>
                            </div>
                        @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
